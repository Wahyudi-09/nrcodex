<body>
	<!-- ======= Top Bar ======= -->
	<section id="topbar" class="d-none d-lg-block">
		<div class="container clearfix">
			<div class="contact-info float-left">
				<i class="icofont-envelope"></i><a href="mailto:bisnisdigital@umsrappang.com">bisnisdigital@umsrapapng.com</a>
				<i class="icofont-phone"></i> <a href="#" style="color: white;"> +1 234 5678 89</a>

			</div>
			<div class="social-links float-right">
				<a href="#" class="twitter"><i class="icofont-twitter"></i></a>
				<a href="#" class="facebook"><i class="icofont-facebook"></i></a>
				<a href="#" class="instagram"><i class="icofont-instagram"></i></a>
				<a href="#" class="skype"><i class="icofont-skype"></i></a>
				<a href="#" class="linkedin"><i class="icofont-linkedin"></i></i></a>
			</div>
		</div>
	</section>