<footer id="footer">
	<div class="container">
		<div class="copyright">
			&copy; Copyright <strong><span>Bisnis Digital</span></strong>
		</div>

	</div>
</footer><!-- End  Footer -->

<a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

<!-- Vendor JS Files -->
<script src="assets/dosen/vendor/jquery/jquery.min.js"></script>
<script src="assets/dosen/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/dosen/vendor/jquery.easing/jquery.easing.min.js"></script>
<script src="assets/dosen/vendor/php-email-form/validate.js"></script>
<script src="assets/dosen/vendor/waypoints/jquery.waypoints.min.js"></script>
<script src="assets/dosen/vendor/counterup/counterup.min.js"></script>
<script src="assets/dosen/vendor/isotope-layout/isotope.pkgd.min.js"></script>
<script src="assets/dosen/vendor/venobox/venobox.min.js"></script>
<script src="assets/dosen/vendor/owl.carousel/owl.carousel.min.js"></script>
<script src="assets/dosen/vendor/typed.js/typed.min.js"></script>
<script src="assets/dosen/vendor/aos/aos.js"></script>

<!-- Template Main JS File -->
<script src="assets/dosen/js/main.js"></script>

</body>

</html>